﻿namespace Library.Data.Constants
{
    public class DataConstants
    {
    }
}
